(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/lib/loader.js?!./src/home/home.scss":
/*!******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-oneOf-5-1!./node_modules/postcss-loader/src??postcss!./node_modules/sass-loader/lib/loader.js??ref--6-oneOf-5-3!./src/home/home.scss ***!
  \******************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "* {\n  margin: 0;\n  padding: 0;\n  font-family: \"Franklin Gothic Medium\", \"Arial Narrow\", Arial, sans-serif; }\n\nbody {\n  background-image: url(\"https://media.architecturaldigest.com/photos/5772a29056d7d0330986bc54/16:9/w_1280,c_limit/michael-jackson-home-01.jpg\");\n  background-repeat: no-repeat;\n  height: 650px;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-color: #cccccc; }\n\n.main {\n  max-width: 1200px;\n  margin: auto; }\n  .main ul {\n    list-style-type: none;\n    float: right;\n    margin-top: 30px; }\n  .main ul li {\n    display: inline-block; }\n  .main ul li a {\n    text-decoration: none;\n    color: black;\n    padding: 5 px 20px;\n    border: 1px solid transparent;\n    transition: 0.6s ease;\n    margin-right: 10px; }\n  .main ul li a:hover {\n    background-color: white;\n    color: #000; }\n  .main ul li.active a {\n    background-color: #ffffff;\n    color: #000; }\n\n.logo img {\n  float: left;\n  width: 150px;\n  height: auto; }\n\n.AutoComplete-wrapper {\n  display: -webkit-flex;\n  display: flex;\n  max-width: 600px;\n  min-width: 100px;\n  /*height: 500px;*/\n  text-align: center;\n  margin: 0 auto 0 auto;\n  padding-top: 300px;\n  padding-left: 120px; }\n\n.Search {\n  height: 39px;\n  border-radius: 15px;\n  border: 1px solid #70a1ff;\n  transition: border 0.8s ease-out;\n  padding: 8px;\n  margin-left: 5px;\n  font-family: Oxygen, sans-serif;\n  font-size: 17px;\n  color: #15779b;\n  background: rgba(15, 15, 15, 0.01);\n  background-color: #ffffff; }\n\n.Search:hover {\n  background: #15779b;\n  border: 1px solid white;\n  cursor: pointer;\n  color: white; }\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/home/Autocomplete.css":
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-oneOf-3-1!./node_modules/postcss-loader/src??postcss!./src/home/Autocomplete.css ***!
  \**************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".AutoCompleteText {\n  width: 100%;\n  /*border: 1px solid #195363;*/\n  /*box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.1), 0 2 4 1 rgba(0, 0, 0, 0.18);*/\n  font-family: Arial, Helvetica, sans-serif;\n  font-size: 14px;\n  color: rgba(0, 0, 0, 0.73);\n}\n\n.AutoCompleteText input {\n  width: 100%;\n  border: 1px solid #15779b;\n  border-radius: 40px;\n  font-family: Arial, Helvetica, sans-serif;\n  font-size: 15px;\n  color: rgba(0, 0, 0, 0.73);\n  padding: 10px 10px;\n  box-sizing: border-box;\n  outline: none;\n}\n\n.AutoCompleteText input:hover{\n  background-color: #f7fdff;\n}\n\n.AutoCompleteText ul {\n  overflow: visible;\n  background-image: linear-gredient(to bottom left, white, blue);\n  position: absolute;\n  list-style-type: none;\n  text-align: left;\n  margin: 0;\n  padding: 0;\n  border-bottom-left-radius: 10px;\n  border-bottom-right-radius: 10px;\n}\n.AutoCompleteText ul::before {\n  content: \"\";\n}\n.AutoCompleteText li {\n  border-bottom: 1px solid #15779b;\n  border-bottom-left-radius: 10px;\n  padding: 10px 15px;\n  width: auto;  \n  cursor: pointer;\n}\n.AutoCompleteText li:hover {\n  background-color: #f7fbfc ;\n} ", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-oneOf-3-1!./node_modules/postcss-loader/src??postcss!./src/index.css ***!
  \**************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "body {\n  margin: 0;\n  padding: 0;\n  font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", \"Roboto\", \"Oxygen\",\n    \"Ubuntu\", \"Cantarell\", \"Fira Sans\", \"Droid Sans\", \"Helvetica Neue\",\n    sans-serif;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\ncode {\n  font-family: source-code-pro, Menlo, Monaco, Consolas, \"Courier New\",\n    monospace;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/login/login.css":
/*!********************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-oneOf-3-1!./node_modules/postcss-loader/src??postcss!./src/login/login.css ***!
  \********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var escape = __webpack_require__(/*! ../../node_modules/css-loader/lib/url/escape.js */ "./node_modules/css-loader/lib/url/escape.js");
exports = module.exports = __webpack_require__(/*! ../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "html,\nbody {\n  /*background-image: url(\"https://media.architecturaldigest.com/photos/5772a29056d7d0330986bc54/16:9/w_1280,c_limit/michael-jackson-home-01.jpg\");\n  */background-repeat: no-repeat;\n  height: 100%;\n  width: auto;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: 100% 100%;\n  background-color: #ffffff;\n  font-weight: bold;\n  font-size: 17px;\n}\n\n#root {\n  width: 100%;\n  height: 100%;\n  box-sizing: border-box;\n  background-color: #ffffff;\n}\n\n.root-container {\n  margin-top: 200px;\n  width: 100%;\n  height: 100%;\n  display: -webkit-flex;\n  display: flex;\n  -webkit-justify-content: center;\n          justify-content: center;\n  -webkit-align-items: center;\n          align-items: center;\n  -webkit-flex-direction: column;\n          flex-direction: column;\n  color: #bb1e1e;\n  background-color: #ffffff;\n}\n\n.box-controller {\n  visibility: visible;\n  display: -webkit-flex;\n  display: flex;\n  max-width: 24em;\n  min-width: 10em;\n  height: 35px;\n  box-shadow: 100px 100px 20px zpx rgba(15, 15, 15, 0.2);\n  /*margin-bottom: 30px;*/\n  -webkit-align-items: center;\n          align-items: center;\n  transition: visibility 0.5s ease-out;\n}\n\n.controller {\n  -webkit-flex: 1 1;\n          flex: 1 1;\n  text-align: center;\n  height: 100%;\n  line-height: 2;\n  cursor: pointer;\n  background-color: #a7c4f2;\n  border-radius: 3px;\n  box-shadow: 0px 5px 5px 5px rgba(50, 50, 100, 0.3);\n  margin-left: 10px;\n  margin-right: 10px;\n}\n\n.controller:hover{\n  background-color: #81a6e2;\n  transition: background-color 0.3s ease-out;\n}\n\n.selected-controller {\n  box-shadow: 0px 5px 5px 5px rgba(50, 50, 100, 0.9);\n  /*transition: border 0.5s ease-out;*/\n  /*border-bottom: 2px solid #70a1ff;*/\n}\n\n.box-container {\n  background-image: url(" + escape(__webpack_require__(/*! ./login-img.png */ "./src/login/login-img.png")) + ");\n  display: -webkit-flex;\n  display: flex;\n  -webkit-flex-direction: column;\n          flex-direction: column;\n  background-size: contain;\n  background-repeat: no-repeat;\n  background-position: center;\n  /*object-fit: contain;*/\n  max-width: 50em;\n  min-width: 40em;\n  /*box-shadow: 0px 0px 20px 0px rgba(15, 15, 15, 0.2);*/\n  border-radius: 6px;\n  padding: 100px;\n  position: relative;\n\n  /*background-color: antiquewhite;*/\n}\n\n.inner-container {\n  transition: visibility 1s ease-out;\n  padding-left: 40%;\n\n}\n\n.inner-container.show {\n  visibility: visible;\n}\n\n.header {\n  text-align: center;\n  padding: 5px;\n  margin-bottom: 17px;\n  /* margin-left: 35px; */\n  /* margin-right: 35px; */\n  font-family: Ozxgen, sans-serif;\n  font-size: 22px;\n  border-bottom: 2px solid #70a1ff;\n}\n\n.box {\n  display: -webkit-flex;\n  display: flex;\n  -webkit-flex-direction: column;\n          flex-direction: column;\n  -webkit-justify-content: center;\n          justify-content: center;\n}\n\n.input-group {\n  display: -webkit-flex;\n  display: flex;\n  -webkit-flex-direction: column;\n          flex-direction: column;\n  margin-top: 5px;\n  margin-bottom: 5px;\n}\n\n.login-label {\n  font-family: Oxygen, sans-serif;\n  font-size: 20px;\n  font-weight: 600;\n  padding-left: 5px;\n}\n\n.login-input {\n  height: 2.1em;\n  border-radius: 5px;\n  border: 2px solid #70a1ff;\n  transition: border 0.2s ease-out;\n  padding: 10px;\n  margin-top: 10px;\n  font-family: Oxygen, sans-serif;\n  font-size: 19px;\n  color: #3e3e42;\n  background: rgba(15, 15, 15, 0.01);\n}\n\n.login-input:hover {\n  border: 3px solid #70a1ff;\n}\n\n.login-input:focus {\n  border: 2px solid #6565e7;\n  box-shadow: 0px 0px 20px rgba(15, 15, 15, 0.2);\n}\n\n.login-input::-webkit-input-placeholder {\n  font-family: Oxygen, sans-serif;\n  font-size: 16px;\n  color: rgba(15, 15, 15, 0.4);\n}\n\n.login-input::-ms-input-placeholder {\n  font-family: Oxygen, sans-serif;\n  font-size: 16px;\n  color: rgba(15, 15, 15, 0.4);\n}\n\n.login-input::placeholder {\n  font-family: Oxygen, sans-serif;\n  font-size: 16px;\n  color: rgba(15, 15, 15, 0.4);\n}\n\n.login-btn {\n  padding: 2px 30px;\n  /* background-color: #417cef; */\n  border: 0;\n  font-size: 18px;\n  border-radius: 3px;\n  font-family: Oxygen, sans-serif;\n  background-color: rgba(255, 255, 255, 0.03);\n  margin-top: 20px;\n  padding-top: 5px;\n  padding-bottom: 5px;\n  font-weight: bold;\n  border: 2px solid #417cef;\n  transition: background-color 0.3s ease-out;\n  cursor: pointer;\n}\n\n.login-btn:hover,\n.login-btn:focus {\n  background-color: #417cef;\n  color: white;\n}\n\n.danger-error {\n  color: #e74c3c;\n  font-size: 16px;\n  font-weight: normal;\n}\n\n.password-state {\n  display: -webkit-flex;\n  display: flex;\n  -webkit-flex-direction: row;\n          flex-direction: row;\n  margin-top: 20px;\n}\n\n.pwd {\n  height: 6px;\n  -webkit-flex: 1 1;\n          flex: 1 1;\n  visibility: hidden;\n}\n\n\n.show {\n  visibility: visible;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/navbar/navbar.css":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-oneOf-3-1!./node_modules/postcss-loader/src??postcss!./src/navbar/navbar.css ***!
  \**********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports
exports.push([module.i, "@import url(https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css);", ""]);

// module
exports.push([module.i, "html, body{\n  padding: 0px;\n\n}\n\n#root{\n  padding: 0px;\n}\n\n.nav-bar {\n  width: 100%;\n  height: 50px;\n  margin: 0px;\n  padding: 0px;\n  position: absolute;\n  overflow: hidden;\n  float: right;\n  background-image: linear-gradient(to right, #68c2ff, white);\n}\n\n\n.item{\n  height: auto;\n  width: 60px;\n  float: right;\n  text-align: center;\n  padding: 15px 20px;\n  background-color: #b2e2ff;\n  border-radius: 10px;\n}\n\n.item:hover{\n  background-color: #6fc7fc;\n  cursor: pointer;\n}\n\n.header{\n  height: auto;\n  width: auto;\n  float: left;\n  padding: 10px 5px;\n  margin-bottom: 0px;\n  border-radius: 0px;\n  font-size: 30px;\n}\n\n.userinfo{\n  height: auto;\n  width: 120px;\n  float: right;\n  text-align: center;\n  padding: 15px 20px;\n}", ""]);

// exports


/***/ }),

/***/ "./src/App.js":
/*!********************!*\
  !*** ./src/App.js ***!
  \********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _logo_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./logo.svg */ "./src/logo.svg");
/* harmony import */ var _logo_svg__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_logo_svg__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var _login_LoginRegisterBox_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./login/LoginRegisterBox.js */ "./src/login/LoginRegisterBox.js");
/* harmony import */ var _home_Home_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./home/Home.js */ "./src/home/Home.js");
/* harmony import */ var _navbar_navbar_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./navbar/navbar.js */ "./src/navbar/navbar.js");





var _jsxFileName = "/home/itsme/mydata/SEN/estate_locator-SEN-CLIENT/src/App.js";







var appurl = "http://localhost:1433";

var App =
/*#__PURE__*/
function (_React$Component) {
  Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__["default"])(App, _React$Component);

  function App() {
    Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, App);

    return Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__["default"])(this, Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__["default"])(App).apply(this, arguments));
  }

  Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(App, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_8__["BrowserRouter"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 14
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 15
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_8__["Switch"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 16
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_8__["Route"], {
        path: "/",
        component: _login_LoginRegisterBox_js__WEBPACK_IMPORTED_MODULE_9__["LoginRegisterBox"],
        exact: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 17
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 18
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_8__["Route"], {
        path: "/home",
        component: _home_Home_js__WEBPACK_IMPORTED_MODULE_10__["Home"],
        __source: {
          fileName: _jsxFileName,
          lineNumber: 19
        },
        __self: this
      })))));
    }
  }]);

  return App;
}(react__WEBPACK_IMPORTED_MODULE_5___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (App);

/***/ }),

/***/ "./src/home/Autocomplete.css":
/*!***********************************!*\
  !*** ./src/home/Autocomplete.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../node_modules/css-loader??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./Autocomplete.css */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/home/Autocomplete.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../node_modules/css-loader??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./Autocomplete.css */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/home/Autocomplete.css", function() {
		var newContent = __webpack_require__(/*! !../../node_modules/css-loader??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./Autocomplete.css */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/home/Autocomplete.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	});

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./src/home/Autocomplete.js":
/*!**********************************!*\
  !*** ./src/home/Autocomplete.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var _Autocomplete_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Autocomplete.css */ "./src/home/Autocomplete.css");
/* harmony import */ var _Autocomplete_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_Autocomplete_css__WEBPACK_IMPORTED_MODULE_7__);





var _jsxFileName = "/home/itsme/mydata/SEN/estate_locator-SEN-CLIENT/src/home/Autocomplete.js";




var AutoComplete =
/*#__PURE__*/
function (_React$Component) {
  Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__["default"])(AutoComplete, _React$Component);

  function AutoComplete(props) {
    var _this;

    Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, AutoComplete);

    _this = Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__["default"])(this, Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__["default"])(AutoComplete).call(this, props));

    _this.onTextChanged = function (e) {
      var value = e.target.value;
      var suggestions = [];

      if (value.length > 0) {
        var regEx = new RegExp("^".concat(value), "i");
        suggestions = _this.items.sort().filter(function (v) {
          return regEx.test(v);
        });
      }

      _this.setState(function () {
        return {
          suggestions: suggestions,
          text: value
        };
      });
    };

    _this.items = [];
    _this.state = {
      suggestions: ['denis', 'richie', 'malik', 'sanamsdasfsgdhf'],
      text: ""
    };
    return _this;
  }

  Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(AutoComplete, [{
    key: "renderSuggestions",
    value: function renderSuggestions() {
      var _this2 = this;

      var suggestions = this.state.suggestions;

      if (suggestions.length === 0) {
        return null;
      }

      return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("ul", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 29
        },
        __self: this
      }, suggestions.map(function (item) {
        return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("li", {
          onClick: function onClick() {
            return _this2.suggestionselected(item);
          },
          __source: {
            fileName: _jsxFileName,
            lineNumber: 31
          },
          __self: this
        }, item);
      }));
    }
  }, {
    key: "suggestionselected",
    value: function suggestionselected(value) {
      this.setState(function () {
        return {
          text: value,
          suggestions: []
        };
      });
    }
  }, {
    key: "render",
    value: function render() {
      var text = this.state.text;
      return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: "AutoCompleteText",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 45
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("input", {
        value: text,
        onChange: this.onTextChanged,
        type: "text",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 46
        },
        __self: this
      }), this.renderSuggestions());
    }
  }]);

  return AutoComplete;
}(react__WEBPACK_IMPORTED_MODULE_5___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (AutoComplete);

/***/ }),

/***/ "./src/home/Home.js":
/*!**************************!*\
  !*** ./src/home/Home.js ***!
  \**************************/
/*! exports provided: Home */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Home", function() { return Home; });
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var _Autocomplete__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Autocomplete */ "./src/home/Autocomplete.js");
/* harmony import */ var _home_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./home.scss */ "./src/home/home.scss");
/* harmony import */ var _home_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_home_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");





var _jsxFileName = "/home/itsme/mydata/SEN/estate_locator-SEN-CLIENT/src/home/Home.js";





var Option = _Autocomplete__WEBPACK_IMPORTED_MODULE_7__["default"].Option;

function onSelect(value) {
  console.log("onSelect", value);
}

var Home =
/*#__PURE__*/
function (_React$Component) {
  Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__["default"])(Home, _React$Component);

  function Home() {
    var _getPrototypeOf2;

    var _this;

    Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, Home);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__["default"])(this, (_getPrototypeOf2 = Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__["default"])(Home)).call.apply(_getPrototypeOf2, [this].concat(args)));
    _this.state = {
      dataSource: ["denis", "derek", "damien", "shadu", "shamiana"]
    };

    _this.handleSearch = function (value) {
      _this.setState({
        dataSource: !value ? [] : [value + value + value, value + value, value]
      });
    };

    return _this;
  }

  Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(Home, [{
    key: "onSelect",
    value: function onSelect(value) {
      console.log("onSelect", value);
    }
  }, {
    key: "render",
    value: function render() {
      var dataSource = this.state.dataSource;
      return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_5___default.a.Fragment, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 31
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("header", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 32
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        class: "main",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 33
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        class: "logo",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 34
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("img", {
        src: __webpack_require__(/*! ./logo.png */ "./src/home/logo.png"),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 35
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("ul", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 37
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("li", {
        class: "active",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 38
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("a", {
        href: "#",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 39
        },
        __self: this
      }, "Home")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("li", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 41
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_6__["Link"], {
        to: "/auth",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 42
        },
        __self: this
      }, "Login")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("li", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 44
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("a", {
        href: "#",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 45
        },
        __self: this
      }, "About")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("li", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 47
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("a", {
        href: "#",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 48
        },
        __self: this
      }, "Contact Us")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("li", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 50
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("a", {
        href: "#",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 51
        },
        __self: this
      }, "Careers"))))), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: "AutoComplete-wrapper",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 56
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_Autocomplete__WEBPACK_IMPORTED_MODULE_7__["default"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 57
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("button", {
        type: "button",
        className: "Search",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 58
        },
        __self: this
      }, "Search")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 62
        },
        __self: this
      }, "HElloo guys"));
    }
  }]);

  return Home;
}(react__WEBPACK_IMPORTED_MODULE_5___default.a.Component);

/***/ }),

/***/ "./src/home/home.scss":
/*!****************************!*\
  !*** ./src/home/home.scss ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../node_modules/css-loader??ref--6-oneOf-5-1!../../node_modules/postcss-loader/src??postcss!../../node_modules/sass-loader/lib/loader.js??ref--6-oneOf-5-3!./home.scss */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/lib/loader.js?!./src/home/home.scss");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../node_modules/css-loader??ref--6-oneOf-5-1!../../node_modules/postcss-loader/src??postcss!../../node_modules/sass-loader/lib/loader.js??ref--6-oneOf-5-3!./home.scss */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/lib/loader.js?!./src/home/home.scss", function() {
		var newContent = __webpack_require__(/*! !../../node_modules/css-loader??ref--6-oneOf-5-1!../../node_modules/postcss-loader/src??postcss!../../node_modules/sass-loader/lib/loader.js??ref--6-oneOf-5-3!./home.scss */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/lib/loader.js?!./src/home/home.scss");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	});

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./src/home/logo.png":
/*!***************************!*\
  !*** ./src/home/logo.png ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/logo.f8d813a1.png";

/***/ }),

/***/ "./src/index.css":
/*!***********************!*\
  !*** ./src/index.css ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../node_modules/css-loader??ref--6-oneOf-3-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../node_modules/css-loader??ref--6-oneOf-3-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css", function() {
		var newContent = __webpack_require__(/*! !../node_modules/css-loader??ref--6-oneOf-3-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	});

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "./node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index.css */ "./src/index.css");
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_index_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _App__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./App */ "./src/App.js");
/* harmony import */ var _serviceWorker__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./serviceWorker */ "./src/serviceWorker.js");
var _jsxFileName = "/home/itsme/mydata/SEN/estate_locator-SEN-CLIENT/src/index.js";





react_dom__WEBPACK_IMPORTED_MODULE_1___default.a.render(react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_App__WEBPACK_IMPORTED_MODULE_3__["default"], {
  __source: {
    fileName: _jsxFileName,
    lineNumber: 7
  },
  __self: undefined
}), document.getElementById('root')); // If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA

_serviceWorker__WEBPACK_IMPORTED_MODULE_4__["unregister"]();

/***/ }),

/***/ "./src/login/LoginBox.js":
/*!*******************************!*\
  !*** ./src/login/LoginBox.js ***!
  \*******************************/
/*! exports provided: LoginBox */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginBox", function() { return LoginBox; });
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _logo_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./logo.svg */ "./src/login/logo.svg");
/* harmony import */ var _logo_svg__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_logo_svg__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _login_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./login.css */ "./src/login/login.css");
/* harmony import */ var _login_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_login_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/esm/react-router.js");






var _jsxFileName = "/home/itsme/mydata/SEN/estate_locator-SEN-CLIENT/src/login/LoginBox.js";





var appurl = "http://localhost:1433";
var LoginBox =
/*#__PURE__*/
function (_React$Component) {
  Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__["default"])(LoginBox, _React$Component);

  function LoginBox(props) {
    var _this;

    Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__["default"])(this, LoginBox);

    _this = Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__["default"])(this, Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__["default"])(LoginBox).call(this, props));
    _this.state = {
      username: "",
      password: "",
      errors: [],
      redirect: false
    };
    return _this;
  }

  Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__["default"])(LoginBox, [{
    key: "showValidationErr",
    value: function showValidationErr(elm, msg) {
      this.setState(function (prevState) {
        return {
          errors: [].concat(Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState.errors), [{
            elm: elm,
            msg: msg
          }])
        };
      });
    }
  }, {
    key: "clearValidationErr",
    value: function clearValidationErr(elm) {
      this.setState(function (prevState) {
        var newArr = [];
        var _iteratorNormalCompletion = true;
        var _didIteratorError = false;
        var _iteratorError = undefined;

        try {
          for (var _iterator = prevState.errors[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var err = _step.value;

            if (elm != err.elm) {
              newArr.push(err);
            }
          }
        } catch (err) {
          _didIteratorError = true;
          _iteratorError = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
              _iterator.return();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }

        return {
          errors: newArr
        };
      });
    }
  }, {
    key: "onUsernameChange",
    value: function onUsernameChange(param) {
      this.setState({
        username: param.target.value
      });
      this.clearValidationErr("username");
    }
  }, {
    key: "onPasswordChange",
    value: function onPasswordChange(param) {
      this.setState({
        password: param.target.value
      });
      this.clearValidationErr("password");
    }
  }, {
    key: "submitLogin",
    value: function submitLogin(param) {
      if (this.state.username == "") {
        this.showValidationErr("username", "username cannot be empty");
      }

      if (this.state.password == "") {
        this.showValidationErr("password", "password cannot be empty");
      }

      console.log("login going");

      if (this.state.username !== "" && this.state.password !== "") {
        // jquery
        jquery__WEBPACK_IMPORTED_MODULE_9___default.a.ajax({
          url: appurl + '/account/logIn',
          method: 'POST',
          data: {
            email: this.state.username,
            password: this.state.password
          },
          success: function (result) {
            if (result.login) {
              console.log("login success");
              this.setState({
                redirect: true
              });
            } else {
              console.log("login failed");
            }
          }.bind(this)
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var redirect = this.state.redirect;
      var usernameErr = null,
          passwordErr = null;
      var _iteratorNormalCompletion2 = true;
      var _didIteratorError2 = false;
      var _iteratorError2 = undefined;

      try {
        for (var _iterator2 = this.state.errors[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
          var err = _step2.value;

          if (err.elm == "username") {
            usernameErr = err.msg;
          }

          if (err.elm == "password") {
            passwordErr = err.msg;
          }
        }
      } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion2 && _iterator2.return != null) {
            _iterator2.return();
          }
        } finally {
          if (_didIteratorError2) {
            throw _iteratorError2;
          }
        }
      }

      if (redirect) {
        console.log("redirecting");
        return react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(react_router__WEBPACK_IMPORTED_MODULE_10__["Redirect"], {
          to: "/Home/",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 85
          },
          __self: this
        });
      }

      return react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("div", {
        className: "inner-container",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 88
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("div", {
        className: "header",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 89
        },
        __self: this
      }, "Login"), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("div", {
        className: "box",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 90
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("div", {
        className: "input-group",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 91
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("label", {
        htmlFor: "username",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 92
        },
        __self: this
      }, "Username"), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("input", {
        type: "text",
        name: "username",
        className: "login-input",
        placeholder: "Enter Username",
        onChange: this.onUsernameChange.bind(this),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 93
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("small", {
        className: "danger-error",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 100
        },
        __self: this
      }, usernameErr ? usernameErr : "")), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("div", {
        className: "input-group",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 105
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("label", {
        htmlFor: "password",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 106
        },
        __self: this
      }, "Password"), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("input", {
        type: "password",
        name: "password",
        className: "login-input",
        placeholder: "Enter Password",
        onChange: this.onPasswordChange.bind(this),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 107
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("small", {
        className: "danger-error",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 114
        },
        __self: this
      }, passwordErr ? passwordErr : "")), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("button", {
        type: "button",
        className: "login-btn",
        onClick: this.submitLogin.bind(this),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 119
        },
        __self: this
      }, "Login")));
    }
  }]);

  return LoginBox;
}(react__WEBPACK_IMPORTED_MODULE_6___default.a.Component);

/***/ }),

/***/ "./src/login/LoginRegisterBox.js":
/*!***************************************!*\
  !*** ./src/login/LoginRegisterBox.js ***!
  \***************************************/
/*! exports provided: LoginRegisterBox */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginRegisterBox", function() { return LoginRegisterBox; });
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _logo_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./logo.svg */ "./src/login/logo.svg");
/* harmony import */ var _logo_svg__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_logo_svg__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _login_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./login.css */ "./src/login/login.css");
/* harmony import */ var _login_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_login_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _LoginBox_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./LoginBox.js */ "./src/login/LoginBox.js");
/* harmony import */ var _RegisterBox_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./RegisterBox.js */ "./src/login/RegisterBox.js");





var _jsxFileName = "/home/itsme/mydata/SEN/estate_locator-SEN-CLIENT/src/login/LoginRegisterBox.js";






var LoginRegisterBox =
/*#__PURE__*/
function (_React$Component) {
  Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__["default"])(LoginRegisterBox, _React$Component);

  function LoginRegisterBox(props) {
    var _this;

    Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, LoginRegisterBox);

    _this = Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__["default"])(this, Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__["default"])(LoginRegisterBox).call(this, props));
    _this.state = {
      LoginOpen: true,
      RegisterOpen: false
    };
    return _this;
  }

  Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(LoginRegisterBox, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: "root-container",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 19
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: "box-container",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 20
        },
        __self: this
      }, this.state.LoginOpen && react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_LoginBox_js__WEBPACK_IMPORTED_MODULE_9__["LoginBox"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 21
        },
        __self: this
      }), this.state.RegisterOpen && react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_RegisterBox_js__WEBPACK_IMPORTED_MODULE_10__["RegisterBox"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 22
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: "box-controller",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 24
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: "controller " + (this.state.LoginOpen ? "selected-controller" : ""),
        onClick: this.LoginBox.bind(this),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 25
        },
        __self: this
      }, "Login"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: "controller " + (this.state.RegisterOpen ? "selected-controller" : ""),
        onClick: this.RegisterBox.bind(this),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 34
        },
        __self: this
      }, "Sign-up")));
    }
  }, {
    key: "LoginBox",
    value: function LoginBox() {
      this.setState({
        LoginOpen: true,
        RegisterOpen: false
      });
    }
  }, {
    key: "RegisterBox",
    value: function RegisterBox() {
      this.setState({
        RegisterOpen: true,
        LoginOpen: false
      });
    }
  }]);

  return LoginRegisterBox;
}(react__WEBPACK_IMPORTED_MODULE_5___default.a.Component);

/***/ }),

/***/ "./src/login/RegisterBox.js":
/*!**********************************!*\
  !*** ./src/login/RegisterBox.js ***!
  \**********************************/
/*! exports provided: RegisterBox */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterBox", function() { return RegisterBox; });
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _logo_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./logo.svg */ "./src/login/logo.svg");
/* harmony import */ var _logo_svg__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_logo_svg__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _login_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./login.css */ "./src/login/login.css");
/* harmony import */ var _login_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_login_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_9__);






var _jsxFileName = "/home/itsme/mydata/SEN/estate_locator-SEN-CLIENT/src/login/RegisterBox.js";




var appurl = "http://localhost:1433";
var RegisterBox =
/*#__PURE__*/
function (_React$Component) {
  Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_5__["default"])(RegisterBox, _React$Component);

  function RegisterBox(props) {
    var _this;

    Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__["default"])(this, RegisterBox);

    _this = Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__["default"])(this, Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__["default"])(RegisterBox).call(this, props));
    _this.state = {
      username: "",
      password: "",
      password2: "",
      errors: []
    };
    return _this;
  }

  Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__["default"])(RegisterBox, [{
    key: "showValidationErr",
    value: function showValidationErr(elm, msg) {
      this.setState(function (prevState) {
        return {
          errors: [].concat(Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState.errors), [{
            elm: elm,
            msg: msg
          }])
        };
      });
    }
  }, {
    key: "clearValidationErr",
    value: function clearValidationErr(elm) {
      this.setState(function (prevState) {
        var newArr = [];
        var _iteratorNormalCompletion = true;
        var _didIteratorError = false;
        var _iteratorError = undefined;

        try {
          for (var _iterator = prevState.errors[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var err = _step.value;

            if (elm != err.elm) {
              newArr.push(err);
            }
          }
        } catch (err) {
          _didIteratorError = true;
          _iteratorError = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
              _iterator.return();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }

        return {
          errors: newArr
        };
      });
    }
  }, {
    key: "onUsernameChange",
    value: function onUsernameChange(param) {
      this.setState({
        username: param.target.value
      });
      this.clearValidationErr("username");
    }
  }, {
    key: "onPasswordChange",
    value: function onPasswordChange(param) {
      this.setState({
        password: param.target.value
      });
      this.clearValidationErr("password");
    }
  }, {
    key: "onPassword2Change",
    value: function onPassword2Change(param) {
      this.setState({
        password2: param.target.value
      });
      this.clearValidationErr("password2");
    }
  }, {
    key: "submitRegister",
    value: function submitRegister(param) {
      console.log('get register request');

      if (this.state.username == "") {
        this.showValidationErr("username", "username cannot be empty");
      }

      if (this.state.password == "" || this.state.password2 == "") {
        this.showValidationErr("password", "password cannot be empty");
      }

      if (this.state.password != this.state.password2) {
        this.showValidationErr("password2", "password doesn't match");
      }

      console.log("register request sent");
      jquery__WEBPACK_IMPORTED_MODULE_9___default.a.ajax({
        url: appurl + '/account/register',
        method: 'POST',
        data: {
          email: this.state.username,
          password: this.state.password,
          password2: this.state.password2
        },
        success: function success(result) {
          console.log(result);
        }
      });
    }
  }, {
    key: "render",
    value: function render() {
      var usernameErr = null,
          passwordErr = null,
          password2Err = null;
      var _iteratorNormalCompletion2 = true;
      var _didIteratorError2 = false;
      var _iteratorError2 = undefined;

      try {
        for (var _iterator2 = this.state.errors[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
          var err = _step2.value;

          if (err.elm == "username") {
            usernameErr = err.msg;
          }

          if (err.elm == "password") {
            passwordErr = err.msg;
          }

          if (err.elm == "password2") {
            password2Err = err.msg;
          }
        }
      } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion2 && _iterator2.return != null) {
            _iterator2.return();
          }
        } finally {
          if (_didIteratorError2) {
            throw _iteratorError2;
          }
        }
      }

      return react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("div", {
        className: "inner-container",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 84
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("div", {
        className: "header",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 85
        },
        __self: this
      }, "Sign-up"), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("div", {
        className: "box",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 86
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("div", {
        className: "input-group",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 87
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("label", {
        htmlFor: "username",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 88
        },
        __self: this
      }, "Username"), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("input", {
        type: "text",
        name: "username",
        className: "login-input",
        placeholder: "Enter Username",
        onChange: this.onUsernameChange.bind(this),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 89
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("small", {
        className: "danger-error",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 96
        },
        __self: this
      }, usernameErr ? usernameErr : "")), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("div", {
        className: "input-group",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 101
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("label", {
        htmlFor: "password",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 102
        },
        __self: this
      }, "Password"), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("input", {
        type: "password",
        name: "password",
        className: "login-input",
        placeholder: "Enter Password",
        onChange: this.onPasswordChange.bind(this),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 103
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("small", {
        className: "danger-error",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 110
        },
        __self: this
      }, passwordErr ? passwordErr : "")), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("div", {
        className: "input-group",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 115
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("label", {
        htmlFor: "password2",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 116
        },
        __self: this
      }, "Confirm Password"), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("input", {
        type: "password",
        name: "password",
        className: "login-input",
        placeholder: "Enter Password Again",
        onChange: this.onPassword2Change.bind(this),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 117
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("small", {
        className: "danger-error",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 124
        },
        __self: this
      }, password2Err ? password2Err : "")), react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement("button", {
        type: "button",
        className: "login-btn",
        onClick: this.submitRegister.bind(this),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 128
        },
        __self: this
      }, "Sign-up")));
    }
  }]);

  return RegisterBox;
}(react__WEBPACK_IMPORTED_MODULE_6___default.a.Component);

/***/ }),

/***/ "./src/login/login-img.png":
/*!*********************************!*\
  !*** ./src/login/login-img.png ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/login-img.9f0f1a16.png";

/***/ }),

/***/ "./src/login/login.css":
/*!*****************************!*\
  !*** ./src/login/login.css ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../node_modules/css-loader??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./login.css */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/login/login.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../node_modules/css-loader??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./login.css */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/login/login.css", function() {
		var newContent = __webpack_require__(/*! !../../node_modules/css-loader??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./login.css */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/login/login.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	});

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./src/login/logo.svg":
/*!****************************!*\
  !*** ./src/login/logo.svg ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/logo.5d5d9eef.svg";

/***/ }),

/***/ "./src/logo.svg":
/*!**********************!*\
  !*** ./src/logo.svg ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/logo.5d5d9eef.svg";

/***/ }),

/***/ "./src/navbar/navbar.css":
/*!*******************************!*\
  !*** ./src/navbar/navbar.css ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../node_modules/css-loader??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./navbar.css */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/navbar/navbar.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../node_modules/css-loader??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./navbar.css */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/navbar/navbar.css", function() {
		var newContent = __webpack_require__(/*! !../../node_modules/css-loader??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./navbar.css */ "./node_modules/css-loader/index.js?!./node_modules/postcss-loader/src/index.js?!./src/navbar/navbar.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	});

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./src/navbar/navbar.js":
/*!******************************!*\
  !*** ./src/navbar/navbar.js ***!
  \******************************/
/*! exports provided: NavBar */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavBar", function() { return NavBar; });
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _navbar_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./navbar.css */ "./src/navbar/navbar.css");
/* harmony import */ var _navbar_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_navbar_css__WEBPACK_IMPORTED_MODULE_7__);





var _jsxFileName = "/home/itsme/mydata/SEN/estate_locator-SEN-CLIENT/src/navbar/navbar.js";



var NavBar =
/*#__PURE__*/
function (_React$Component) {
  Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__["default"])(NavBar, _React$Component);

  function NavBar(props) {
    var _this;

    Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, NavBar);

    _this = Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__["default"])(this, Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__["default"])(NavBar).call(this, props));
    _this.state = {
      isLoggeedIn: false
    };
    return _this;
  }

  Object(_home_itsme_mydata_SEN_estate_locator_SEN_CLIENT_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(NavBar, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        class: "nav-bar",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 15
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        class: "header",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 16
        },
        __self: this
      }, " Estate Locator"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("small", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 17
        },
        __self: this
      }, this.state.isLoggeedIn === true ? react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 19
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        class: "item",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 20
        },
        __self: this
      }, " Sign Up "), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        class: "item",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 21
        },
        __self: this
      }, " Login ")) : react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        class: "userinfo",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 25
        },
        __self: this
      }, "Username")));
    }
  }]);

  return NavBar;
}(react__WEBPACK_IMPORTED_MODULE_5___default.a.Component);

/***/ }),

/***/ "./src/serviceWorker.js":
/*!******************************!*\
  !*** ./src/serviceWorker.js ***!
  \******************************/
/*! exports provided: register, unregister */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "register", function() { return register; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unregister", function() { return unregister; });
// This optional code is used to register a service worker.
// register() is not called by default.
// This lets the app load faster on subsequent visits in production, and gives
// it offline capabilities. However, it also means that developers (and users)
// will only see deployed updates on subsequent visits to a page, after all the
// existing tabs open on the page have been closed, since previously cached
// resources are updated in the background.
// To learn more about the benefits of this model and instructions on how to
// opt-in, read https://bit.ly/CRA-PWA
var isLocalhost = Boolean(window.location.hostname === 'localhost' || // [::1] is the IPv6 localhost address.
window.location.hostname === '[::1]' || // 127.0.0.1/8 is considered localhost for IPv4.
window.location.hostname.match(/^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/));
function register(config) {
  if (false) { var publicUrl; }
}

function registerValidSW(swUrl, config) {
  navigator.serviceWorker.register(swUrl).then(function (registration) {
    registration.onupdatefound = function () {
      var installingWorker = registration.installing;

      if (installingWorker == null) {
        return;
      }

      installingWorker.onstatechange = function () {
        if (installingWorker.state === 'installed') {
          if (navigator.serviceWorker.controller) {
            // At this point, the updated precached content has been fetched,
            // but the previous service worker will still serve the older
            // content until all client tabs are closed.
            console.log('New content is available and will be used when all ' + 'tabs for this page are closed. See https://bit.ly/CRA-PWA.'); // Execute callback

            if (config && config.onUpdate) {
              config.onUpdate(registration);
            }
          } else {
            // At this point, everything has been precached.
            // It's the perfect time to display a
            // "Content is cached for offline use." message.
            console.log('Content is cached for offline use.'); // Execute callback

            if (config && config.onSuccess) {
              config.onSuccess(registration);
            }
          }
        }
      };
    };
  }).catch(function (error) {
    console.error('Error during service worker registration:', error);
  });
}

function checkValidServiceWorker(swUrl, config) {
  // Check if the service worker can be found. If it can't reload the page.
  fetch(swUrl).then(function (response) {
    // Ensure service worker exists, and that we really are getting a JS file.
    var contentType = response.headers.get('content-type');

    if (response.status === 404 || contentType != null && contentType.indexOf('javascript') === -1) {
      // No service worker found. Probably a different app. Reload the page.
      navigator.serviceWorker.ready.then(function (registration) {
        registration.unregister().then(function () {
          window.location.reload();
        });
      });
    } else {
      // Service worker found. Proceed as normal.
      registerValidSW(swUrl, config);
    }
  }).catch(function () {
    console.log('No internet connection found. App is running in offline mode.');
  });
}

function unregister() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.ready.then(function (registration) {
      registration.unregister();
    });
  }
}

/***/ }),

/***/ 0:
/*!**********************************************************************************!*\
  !*** multi ./node_modules/react-dev-utils/webpackHotDevClient.js ./src/index.js ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(/*! /home/itsme/mydata/SEN/estate_locator-SEN-CLIENT/node_modules/react-dev-utils/webpackHotDevClient.js */"./node_modules/react-dev-utils/webpackHotDevClient.js");
module.exports = __webpack_require__(/*! /home/itsme/mydata/SEN/estate_locator-SEN-CLIENT/src/index.js */"./src/index.js");


/***/ })

},[[0,"runtime~main",0]]]);
//# sourceMappingURL=main.chunk.js.map